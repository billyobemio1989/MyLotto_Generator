// Minimal service worker: makes the site installable and shows a friendly offline message.
self.addEventListener('install', e => self.skipWaiting());
self.addEventListener('activate', e => e.waitUntil(self.clients.claim()));
self.addEventListener('fetch', e => {
  if (e.request.method !== 'GET') return;
  e.respondWith(fetch(e.request).catch(() => new Response(
    '<meta name="viewport" content="width=device-width,initial-scale=1">' +
    '<body style="font-family:Arial;padding:2rem"><h2>You are offline</h2>' +
    '<p>Connect to the internet to use the generator.</p></body>',
    {headers: {'Content-Type': 'text/html'}})));
});
